Ссылка на бота https://t.me/coolestplacesbot

Размещен на Heroku, всегда доступен.