from bot import bot 

if __name__ == '__main__':
    bot.polling()
